const form = document.querySelector('#formLogin')
const wrappFormulario = document.querySelector('#wrappFormulario')
const wrappFeed = document.querySelector('#wrappFeed')
const cargarMas = document.querySelector('#cargarMas')
const login = document.querySelector('.login')
const logout = document.querySelector('.logout')
const nav = document.querySelector('nav')

const contentSpinnerLoading = document.querySelector('.contentSpinnerLoading')
contentSpinnerLoading.style.display = "none";
// logout.style.display = 'none';
let page = 1


// Obtiene el Json Web Token
const obtenerJsonWebToken = async( email, password )=>{
    try {
        const response = await fetch('http://localhost:3000/api/login',{
            method: 'POST',
            body: JSON.stringify({ email:email, password:password })
        })
        // console.log('Salida de postData--->', response)
        const { token } = await response.json()

        //Metodo par dejar el JWT en el localStorage
        localStorage.setItem( 'jwt-token', token )

        return token
    } catch (err) {
            console.error( `Error:${err} ` )
    }
}

// Parsea el Jwtoken de alfanumerico a objeto
const parseJwt = (token) => {
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace('-', '+').replace('_', '/');
    return JSON.parse(window.atob(base64));
}

// Funcion que oculta el login y muestra el Feed
const mostrarFeedOcultarForm = ( wrappFormulario, wrappFeed )=>{

    if (login.classList.contains('login')) {

        wrappFormulario.classList.add("d-none");
        wrappFeed.classList.remove('d-none')
        document.querySelector('#navbarText a').classList.remove('d-none')

    }

}

// Funcion que llama las fotos 
const obtenerDataFeed = async( jwt, page=1 )=>{
  
    try {
        const response = await fetch(`http://localhost:3000/api/photos?page=${page}`,{
            method:'GET',
            headers:{
                Authorization: `Bearer ${jwt}`
            }
        })
        const { data } = await response.json();

        if( data ){
            mostrarFeedOcultarForm( wrappFormulario, wrappFeed );
            pintarDataEnFeed( data, page )
        }

        return data;
    } catch (error) {
        console.error(`Error:${error}`)
    }
}

// pintarDataEnFeed
const pintarDataEnFeed = ( data, page ) => {

    const feedFotos = document.querySelector('#feedFotos');

    if(page == 1){
        arr = [...data]
    }
    
    if( page > 1 ){
        // console.log('Mayor que uno')
        let nuevaData = data
        arr = [...arr, ...nuevaData]
    }

    feedFotos.innerHTML =''

    arr.forEach( element => {
        feedFotos.innerHTML += `
        <div class="col col-lg-4" >
        <div class="card mb-3">
        <img src="${element.download_url}" class="card-img-top" loading="lazy">
        <div class="card-body d-flex justify-content-center align-items-center">
          <h6 class="card-title">${element.author}</h6>
        </div>
      </div>
      </div>
        `
    })
}

// Ejecuta el formulario y llama a la funcion obtenerJsonWebToken
form.addEventListener('submit', async (event)=>{

    event.preventDefault();

    const email = document.querySelector('#email').value
    const password = document.querySelector('#password').value
   
    if(email.length != 0 && password.length != 0){

        const JWT = await obtenerJsonWebToken( email , password )

        if( JWT != undefined ){
            await obtenerDataFeed( JWT )
        }else{
            //alert('Debe ingresar correo y contraseña valido');
            $("#myModal").modal("toggle");
            document.querySelector('#mensajeAlerta').innerHTML = `<span class="text-center text-uppercase text-danger font-weight-bold">Debe ingresar correo y contraseña valido!!</span>`
            setTimeout(() => {
                $("#myModal").modal("toggle");    
            }, 3000);
        }

    }else{
        $("#myModal").modal("toggle");
            document.querySelector('#mensajeAlerta').innerHTML = `<span class="text-center text-uppercase text-danger font-weight-bold">Debe ingresar correo y contraseña valido!!</span>`
        setTimeout(() => {
            $("#myModal").modal("toggle");    
        }, 3000);
    }

})


const persistenciaJWT = () =>{
    const token = localStorage.getItem('jwt-token');
    if( token ){
        wrappFormulario.removeChild(form)
        obtenerDataFeed(token)
    }
}

persistenciaJWT()

cargarMas.addEventListener('click',async(e)=>{
    const token = localStorage.getItem('jwt-token');
    e.preventDefault()
    page++

    contentSpinnerLoading.style.display = "flex";
    await obtenerDataFeed(token,page)
    contentSpinnerLoading.style.display = "none";

})

logout.addEventListener('click',(e)=>{

    e.preventDefault();
    nav.classList.remove('login')
    localStorage.clear()
    mostrarFeedOcultarForm( wrappFormulario, wrappFeed )
    window.location.reload();
    
})

