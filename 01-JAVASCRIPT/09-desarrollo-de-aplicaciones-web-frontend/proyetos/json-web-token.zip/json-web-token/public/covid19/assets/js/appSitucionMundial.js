import * as UI from './components/interfaz.js';
import { obtenerJsonWebToken } from './components/obtenerJsonWebToken.js'
import { obtenerDataPaises } from './components/obtenerDataPaises.js'
// import { createTable } from './components/createTable.js';
import { mostrarGraficoOcultarForm } from './components/mostrarGraficoOcultarForm.js'

UI.contentSpinnerLoading.style.display = "none";



//Ejecuta el formulario y llama a la funcion obtenerJsonWebToken
UI.form.addEventListener('submit', async (event)=>{

    event.preventDefault();

    const email = document.querySelector('#email').value
    const password = document.querySelector('#password').value
  
    if( email.length != 0 && password.length != 0 ){
       
        const JWT = await obtenerJsonWebToken( email , password )
       
        if(JWT != undefined ){
            await obtenerDataPaises( JWT )
        }else{
            //alert('Debe ingresar correo y contraseña valido');
            $('#myModal').modal('toggle')
            document.querySelector('#mensajeAlerta').innerHTML = `<span class="text-center text-uppercase text-danger font-weight-bold">Debe ingresar correo y contraseña valida !!</span>`
            setTimeout(() => {
                $('#myModal').modal('toggle')
            }, 3000);
        }

    }else{
        $('#myModal').modal('toggle')
        document.querySelector('#mensajeAlerta').innerHTML = `<span class="text-center text-uppercase text-danger font-weight-bold">Los campos son obligatorios!!</span>`
        setTimeout(() => {
            $('#myModal').modal('toggle')
        }, 3000);
    }

})

//Evento para deslogear
UI.logout.addEventListener('click',(e)=>{
    e.preventDefault();
    localStorage.clear()
    UI.nav.classList.remove('login')
    mostrarGraficoOcultarForm( UI.wrappFormulario, UI.wrappFeed )
    window.location.reload();
})

//Funcion de persistencia
const persistenciaJWT = () =>{
    const token = localStorage.getItem('jwt-token');
    if( token  ){
        console.log('ENTRO TOKEN INIT')
        UI.wrappFormulario.removeChild(UI.form)
        obtenerDataPaises(token)
    }
}

persistenciaJWT()

