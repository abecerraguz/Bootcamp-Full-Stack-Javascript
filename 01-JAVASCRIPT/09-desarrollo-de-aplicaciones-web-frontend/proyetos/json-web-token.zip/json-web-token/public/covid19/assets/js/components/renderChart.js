// FUNCION QUE RENDERIZA LOS GRAFICOS
let myChart;
let myChartCicle;
let myChartLine;
export const renderChart = ( dataFilterAPI, type ) => {
    /*

    Como obtengo los 10 paises con mas casos confirmados :

        1. Recorrer la consulta Array con objetos, 200 paises con ( map(),forEach().... ).
        2. Crear un nuevo arreglo este contiene a cada país en un objeto con los valores que me interesan 
        ( Metodo push() ) (Nombre del país y casos confirmados). El total son 200 paises 
        cada objeto sus claves son  "pais", "confirmados": Ejemplo [ 0: { location:USA, confirmed:242352352 } ]
        3. Utilizar una función de comparación metodo "sort()" para poder oredenar el país con mayores
        casos a menores casos de mayor a menor.
        4. Utilizar el metodo slice() para sacar de los 200 , sólo los 10 paises con mayores casos

        URL de ayuda:
        Como sacar los 5 numeros mayores de un Array
        https://stackoverflow.com/questions/39254218/js-get-top-5-max-elements-from-array

        INCORPORACION DEL GRAFICO CON CHARTJS
        https://www.chartjs.org/docs/latest/

        INSTALAR LIBRERIA de ChartJS
        https://cdnjs.com/libraries/Chart.js

    */

        
   if(type == 'bar'){

    let paises = dataFilterAPI.map( l => l.location )
    let confirmados = dataFilterAPI.map( c => c.confirmed )


    let data = {

        labels: paises,
        options: {
          aspectRatio: 2
        },
        datasets: [{
         label: 'Situación Mundial',
         data: confirmados,
         backgroundColor: [
           'rgba(255, 99, 132, 0.2)',
           'rgba(255, 159, 64, 0.2)',
           'rgba(255, 205, 86, 0.2)',
           'rgba(75, 192, 192, 0.2)',
           'rgba(54, 162, 235, 0.2)',
           'rgba(153, 102, 255, 0.2)',
           'rgba(201, 203, 207, 0.2)',
           'rgba(54, 162, 235, 0.2)',
           'rgba(153, 102, 255, 0.2)',
           'rgba(201, 203, 207, 0.2)'
         ],
         borderColor: [
           'rgb(255, 99, 132)',
           'rgb(255, 159, 64)',
           'rgb(255, 205, 86)',
           'rgb(75, 192, 192)',
           'rgb(54, 162, 235)',
           'rgb(153, 102, 255)',
           'rgb(201, 203, 207)',
           'rgb(54, 162, 235)',
           'rgb(153, 102, 255)',
           'rgb(201, 203, 207)'
         ],
         borderWidth: 1
       }]
       
    }
 

    if (myChart) {
        myChart.destroy();
    }

    myChart = new Chart('myChart', { type:`${type}`, data } )
   }

   if(type == 'pie'){
    //console.log('Salida objeto pie', dataFilterAPI[0].location )

    console.log('dataFilterAPI--->',dataFilterAPI)
    const ModalLabel = document.querySelector('#ModalLabel')
    //ModalLabel.innerHTML = `Situación de ${dataFilterAPI[0].location}`
    ModalLabel.innerHTML = `Situación de ${dataFilterAPI[0].country}`

    let keys = Object.keys(dataFilterAPI[0]);
    let values = Object.values(dataFilterAPI[0])

    keys.shift()
    values.shift()

    let data = {
        labels: keys,
        datasets: [{
         label: 'Situación Mundial',
         data: values,
         backgroundColor: [
           'rgba(255, 99, 132, 1)',
           'rgba(255, 159, 64, 1)',
           'rgba(255, 205, 86, 1)',
           'rgba(75, 192, 192, 1)'
         ],
         hoverOffset:0
       }],
       options : {
        maintainAspectRatio: false,
       } 
    };

    if (myChartCicle) {
        myChartCicle.destroy();
    }
    myChartCicle = new Chart('myChartCicle', { type:`${type}`, data } )
   }

   if(type == 'line'){

    dataFilterAPI.sort((a, b) => a.positive < b.positive ? -1 : a.positive > b.positive ? 1  : 0)
    
    // console.log('Salida de dataFilter-->',dataFilterAPI )
    
    // function parse(str) {
    //     var y = str.substr(0,4),
    //         m = str.substr(6,2) - 1,
    //         d = str.substr(4,2);
    //     var D = new Date(y,m,d);
    //     return (D.getFullYear() == y && D.getMonth() == m && D.getDate() == d) ? D.toLocaleString('es-cl',{
    //       day: 'numeric',
    //       month: 'long',
    //       year: 'numeric'
    //     }) : 'invalid date';
    // }
    

    
    
    // let date = new Date(20200301);
    // console.log(date); 
    // // Output: Tue Jul 21 2020 10:01:14 GMT+0100 (UK Daylight Time)
    // console.log(date.toLocaleString('es-cl'));
    // // Output: 7/21/2020, 10:01:14 AM
  
    // console.log(date.toLocaleString('es-cl', {
    //   weekday: 'short', // long, short, narrow
    //   day: 'numeric', // numeric, 2-digit
    //   year: 'numeric', // numeric, 2-digit
    //   month: 'long', // numeric, 2-digit, long, short, narrow
    //   hour: 'numeric', // numeric, 2-digit
    //   minute: 'numeric', // numeric, 2-digit
    //   second: 'numeric', // numeric, 2-digit
    // }));
   // Output: Tue, July 21, 2020, 10:01:14 AM

    var nuevaFecha = []
    dataFilterAPI.map( info => {
      nuevaFecha.push(  moment(info.date.toString()).locale('es-us').format('DD/MM/YYYY')  )
    })

    const positivosConfirmados = dataFilterAPI.map( info => info.positive)
    const casosNegativos = dataFilterAPI.map( info => info.negative)
    const casosMuertos = dataFilterAPI.map( info => info.deaths)

    console.log('Salida positivosConfirmados', nuevaFecha)

    let data = {
        labels: nuevaFecha,
        maintainAspectRatio: false,
        responsive: true,
        yAxes: [{
          ticks: {
              beginAtZero: true
          }
        }],
        datasets: [
        {
         label: 'Casos Confirmados',
         data: positivosConfirmados,
         fill: true,
         backgroundColor:'rgba(255,196,196,0.4)',
         borderColor: 'rgb(247, 63, 63)',
         tension: 0.1
        },
        {
          label: 'Casos Negativos',
          data: casosNegativos,
          fill: true,
          backgroundColor:'rgba(184,248,174,0.3)',
          borderColor: 'rgb(26, 178, 1)',
          tension: 0.1
        },
        {
          label: 'Muertos',
          data: casosMuertos,
          fill: false,
          borderColor: 'rgb(153, 84, 242)',
          tension: 0.1
        }
      ]


       
    };

    if (myChartLine) {
       myChartLine.destroy();
    }

    myChartLine = new Chart('myChartLine', { type:`${type}`, data } )
   }
    
}