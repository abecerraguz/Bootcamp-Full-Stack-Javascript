import { renderChart } from './renderChart.js'

export const pintarDataEnGrafico = ( data )=> {
   
    let arr = []
    data.map((element) => { 
        arr.push( {
            // location: element.location,
            //confirmed: element.confirmed

            country: element.country,
            confirmed: element.confirmed
        }    )
    })

    
    console.log('Paises arr --->', arr)
    const datosFiltrados = arr.sort((a,b) => b-a).slice(0,10)

    console.log('Salida de filterData-->',arr.sort((a,b) => b-a).slice(0,10))

    renderChart(datosFiltrados,'bar')
  
}