import * as UI from './components/interfaz.js';
import { obtenerDataUSA } from './components/obtenerDataUSA.js'
UI.contentSpinnerLoading.style.display = "none";
UI.wrappFormulario.style.display = "none";

const persistenciaJWT = () =>{
    const token = localStorage.getItem('jwt-token');
    if( token  ){
        console.log('ENTRO TOKEN INIT')
        obtenerDataUSA(token)
    }
}

persistenciaJWT()

UI.logout.addEventListener('click',(e)=>{
    e.preventDefault();
    localStorage.clear()
    UI.nav.classList.remove('login')
    mostrarGraficoOcultarForm( UI.wrappFormulario, UI.wrappFeed )
    window.location.reload();
})
