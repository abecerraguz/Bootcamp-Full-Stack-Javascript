import { renderChart } from './renderChart.js'
import * as UI from './interfaz.js';
// Crear tabla
export const createTable = ( data ) => {

//     let table = document.createElement("table");
//     let tr = document.createElement("tr");
//     let keys = Object.keys(data[0]);
//     console.log( 'Salida de data createtable-->',data )

//     let keyVerInfo = keys.concat('Ver info')
//     table.setAttribute('class','table container my-5')

//         // for (let i=0; i<keyVerInfo.length; i++) {
//         //     let key = keyVerInfo[i]
//         //     let colHeader = document.createElement("th");
//         //     colHeader.appendChild(document.createTextNode(key));
//         //     tr.appendChild(colHeader);
//         // }

//         // table.appendChild(tr);

// //Metodo para ordenar alfabeticamente los paises
// //Para Endpoint de API Externa 
// // data.sort((a, b) => a.location.toLowerCase() < b.location.toLowerCase() ? -1 : a.location.toLowerCase() > b.location.toLowerCase() ? 1  : 0)
// //Para Endpoint local entregado

data.sort((a, b) => a.country.toLowerCase() < b.country.toLowerCase() ? -1 : a.country.toLowerCase() > b.country.toLowerCase() ? 1  : 0)


// wrappFeed.appendChild(table)


// for(let i = 0; i < data.length; i++){
//   let tr = document.createElement('tr');
//   //Para Endpoint de API Externa 
//   //let infoTd = `<td>${data[i].location}</td><td>${data[i].confirmed}</td><td>${data[i].deaths}</td><td>${data[i].recovered}</td><td>${data[i].active}</td><td><button id="${data[i].location}" type="button" class="btn btn-warning btn-sm"><i class="fa-solid fa-magnifying-glass mr-3"></i>Ver</button></td>`
  
//   //Para Endpoint local entregado
//   let infoTd = `<td>${data[i].country}</td><td>${data[i].deaths}</td><td>${data[i].recovered}</td><td>${data[i].active}</td><td>${data[i].confirmed}</td><td><button id="${data[i].country}" type="button" class="btn btn-warning btn-sm w-100"><i class="fa-solid fa-magnifying-glass mr-3"></i>Ver</button></td>`
  
  
//   tr.innerHTML+= infoTd
//   table.appendChild(tr);
// }



data.forEach(( element,index ) =>{
    let infoTd = `<td>${index}</td>
    <td>${element.country}</td>
    <td>${element.deaths}</td>
    <td>${element.recovered}</td>
    <td>${element.active}</td>
    <td>${element.confirmed}</td>
    <td><button id="${element.country}" type="button" class="btn btn-warning btn-sm w-100"><i class="fa-solid fa-magnifying-glass mr-3"></i>Ver</button></td>`
    UI.insertTr.innerHTML+= infoTd
})

// table#one
// h1.hola

let miTablaEnDom = document.querySelectorAll('tbody#insertTr tr td button')
// console.log('Salida de miTablaEnDom--->',miTablaEnDom)

miTablaEnDom.forEach( (element,index,arr) =>{
    element.addEventListener('click', (e)=>{
        $("#myModal").modal("toggle");

        
        //Para Endpoint de API Externa 
        const idButton = arr[index].getAttribute('id')
        console.log('Salida idButton-->', arr)
    
        let filterData = data.filter( element => element.country == idButton );
        console.log('Data Filtrada por país ', filterData)
    })
})

// let miTabla = document.querySelectorAll('table tr td button')
// miTabla.forEach(( element, index, arr )=>{
//     element.addEventListener('click', (e)=>{
        
//         e.preventDefault()
//         $("#myModal").modal("toggle");
//         const idButton = arr[index].getAttribute('id')
        
//         //Para Endpoint de API Externa 
//         //let filterData = data.filter( element => element.location == idButton );
        
//         //Para Endpoint local entregado
//         let filterData = data.filter( element => element.country == idButton );

//         renderChart(filterData,'pie')

//     })
// })

}