import * as UI from './interfaz.js';

//Funcion que oculta el login y muestra el Feed
export const mostrarGraficoOcultarForm = ( wrappFormulario, wrappFeed )=>{

    if (UI.login.classList.contains('login')) {

        UI.wrappFormulario.classList.add("d-none");
        UI.wrappFeed.classList.remove('d-none');
        console.log( 'Salida Maldito-->', UI.content__navUl )
        UI.content__navUl.classList.remove('d-none');
        // document.querySelector('ul').children('ul').remove('d-none')
        document.querySelector('.content__nav div.content__logout').classList.remove('d-none')

        
    }

}