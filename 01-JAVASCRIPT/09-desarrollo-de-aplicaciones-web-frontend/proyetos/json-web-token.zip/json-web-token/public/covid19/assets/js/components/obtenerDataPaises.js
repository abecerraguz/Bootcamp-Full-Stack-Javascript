import * as UI from './interfaz.js';
import { pintarDataEnGrafico } from './pintarDataEnGrafico.js'
import { mostrarGraficoOcultarForm } from './mostrarGraficoOcultarForm.js'
import { createTable } from './createTable.js';
// Obtener Data Paises


export const obtenerDataPaises = async( jwt )=>{
    console.log('Salida dentro obtenerDataPaises', jwt)
    try{
        const response = await fetch(`http://localhost:3000/api/total`,{
            method:'GET',
            headers:{
                Authorization: `Bearer ${jwt}`
            }
        })
        UI.contentSpinnerLoading.style.display = "flex";
        const { data }  = await response.json();
        UI.contentSpinnerLoading.style.display = "none";
        console.log('llega data --->', data )

        if( data ){
            mostrarGraficoOcultarForm( UI.wrappFormulario, UI.wrappFeed );
            pintarDataEnGrafico( data )
            createTable( data )
           
        }
        return data;
    }catch (error) {
        console.error(`Error:${error}`)
    }
}