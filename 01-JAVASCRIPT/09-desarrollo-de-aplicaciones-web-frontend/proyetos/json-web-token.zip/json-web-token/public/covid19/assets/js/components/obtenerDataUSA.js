import * as UI from './interfaz.js';
import { renderChart } from './renderChart.js';


// Obtener Data USA
export const obtenerDataUSA = async( jwt )=>{
  
    try{
        const response = await fetch(`http://localhost:3000/api/country/usa`,{
            method:'GET',
            headers:{
                Authorization: `Bearer ${jwt}`
            }
        })

        UI.contentSpinnerLoading.style.display = "flex";
        const { data }  = await response.json();
        UI.contentSpinnerLoading.style.display = "none";
   
        if( data ){
            
            renderChart( data,'line' )
        }
        return data;
    }catch (error) {
        console.error(`Error:${error}`)
    }
}