const usersDBcovid = require('./../db/usuarios.json')

class UserServiceCovid {

    find({email,password}) {
        const user = usersDBcovid.filter( user => user.email == email && password == user.password )
       return  user[0] || null
    }
    
}

module.exports = {
    UserServiceCovid
}